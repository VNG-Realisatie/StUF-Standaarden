services voor het opvragen van een leeftijd van een persoon of het opvragen van een adres op basis van postcode huisnummer, etc.

RFC's: 

1) -e extentensies niet doen in de basisschema's maar pas later toevoegen met extensies

2) alle andere toeters en bellen eruit halen attibuteGroupEntiteit etc. en ook pas later toevoegen wanneer dat nodig is.

3) stuf-bg uitbreiden met berichtcatalogus met vrije berichten die bovengenoemde services implementeren.

4) gemeentelijst opvraagbaar maken

5) relaties hebben vaak geen eigenschappen, dus die laag weglaten