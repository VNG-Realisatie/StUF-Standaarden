
eigenlijk vreemd dat de gerelateerde entiteit eigenaar in de namespace 'kv' zit in plaats van 'bg'